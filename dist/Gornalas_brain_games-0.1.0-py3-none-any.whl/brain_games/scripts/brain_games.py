#!/usr/bin/env python3
from brain_games import cli
from brain_games.cli import welcome_user

def greet(what):
	print('Welcome to the {}!'.format(what))

def main():
    greet('Brain Games')
    cli.welcome_user()

if __name__ == '__main__':
    main()
